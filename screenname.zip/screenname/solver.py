#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve_it():
    # return a string that is the screen name you would like
    return 'I_R a-N00B'

if __name__ == '__main__':
    print 'This script submits the screen name: ' + solve_it() + '\n'

